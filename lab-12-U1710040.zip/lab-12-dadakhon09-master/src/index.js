import 'bootstrap';
import './scss/styles.scss';
$(document).ready(function(){
 $('.header').height($(window).height());
})